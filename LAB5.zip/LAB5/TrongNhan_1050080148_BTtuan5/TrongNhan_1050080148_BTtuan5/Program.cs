﻿using System;


// Thực hành 1: Tính chu vi diện tích hình chữ nhật
//class Program
//{
//    static void Main(string[] args)
//    {
//        // Nhập chiều dài a
//        Console.Write("Nhap chieu dai  a: ");
//        double a = Convert.ToDouble(Console.ReadLine());

//        // Nhập chiều rộng b
//        Console.Write("Nhap chieu rong  b: ");
//        double b = Convert.ToDouble(Console.ReadLine());

//        // Tính chu vi và diện tích
//        double chuVi = (a + b) * 2;
//        double dienTich = a * b;

//        // Hiển thị kết quả
//        Console.WriteLine("\n--- KET QUA ---");
//        Console.WriteLine("Chu vi hinh chu nhat = " + chuVi);
//        Console.WriteLine("Diẹn tich hinh chu nhat = " + dienTich);

//        // Dừng màn hình để xem kết quả
//        Console.WriteLine("\nNhan phim bat ky de thoat...");
//        Console.ReadKey();
//    }
//}


//Thực hành 2: Tìm số nguyên
//class Program
//{
//    static void Main(string[] args)
//    {
//        // Nhập số nguyên a
//        Console.Write("Nhap so nguyen  a: ");
//        int a = Convert.ToInt32(Console.ReadLine());

//        // Nhập số nguyên b
//        Console.Write("Nhap so nguyen b: ");
//        int b = Convert.ToInt32(Console.ReadLine());

//        // So sánh và in ra kết quả
//        Console.WriteLine("\n--- KET QUA ---");
//        if (a > b)
//        {
//            Console.WriteLine("So lon hon la: " + a);
//        }
//        else if (b > a)
//        {
//            Console.WriteLine("So lon nhat la: " + b);
//        }
//        else
//        {
//            Console.WriteLine("Hai so bang nhau.");
//        }

//        // Dừng màn hình
//        Console.WriteLine("\nNhan phim bat dau de ket thuc...");
//        Console.ReadKey();
//    }
//}



// Thực hành 3: Tìm số có giá trị lớn nhất trong 3 số nguyên a, b, c 


//class Program
//{
//    static void Main(string[] args)
//    {
//        // Nhập số nguyên a
//        Console.Write("Nhap so nguyen  a: ");
//        int a = Convert.ToInt32(Console.ReadLine());

//        // Nhập số nguyên b
//        Console.Write("Nhap so nguyen  b: ");
//        int b = Convert.ToInt32(Console.ReadLine());

//        // Nhập số nguyên c
//        Console.Write("Nhap so nguyen c: ");
//        int c = Convert.ToInt32(Console.ReadLine());

//        // So sánh để tìm số lớn nhất
//        int max = a; // giả sử a lớn nhất

//        if (b > max)
//            max = b;
//        if (c > max)
//            max = c;

//        // Xuất kết quả
//        Console.WriteLine("\n--- KET QUA ---");
//        Console.WriteLine("So lon nhat trong 3 so la: " + max);

//        Console.WriteLine("\nNhan phim bat dau de ket thuc...");
//        Console.ReadKey();
//    }
//}


//Thực hành 4: Cho biết một tháng có bao nhiêu ngày. Biết tháng, năm 


//class Program
//{
//    static void Main(string[] args)
//    {
//        // Nhập tháng
//        Console.Write("Nhap thang (1-12): ");
//        int month = Convert.ToInt32(Console.ReadLine());

//        // Nhập năm
//        Console.Write("Nhap nam: ");
//        int year = Convert.ToInt32(Console.ReadLine());

//        int days;

//        // Xác định số ngày trong tháng
//        switch (month)
//        {
//            case 1:
//            case 3:
//            case 5:
//            case 7:
//            case 8:
//            case 10:
//            case 12:
//                days = 31;
//                break;
//            case 4:
//            case 6:
//            case 9:
//            case 11:
//                days = 30;
//                break;
//            case 2:
//                // Kiểm tra năm nhuận
//                if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0))
//                    days = 29;
//                else
//                    days = 28;
//                break;
//            default:
//                days = 0; // Trường hợp nhập sai tháng
//                break;
//        }

//        // Hiển thị kết quả
//        Console.WriteLine("\n--- KET QUA ---");
//        if (days > 0)
//            Console.WriteLine($"Thang {month}/{year} co {days} ngay .");
//        else
//            Console.WriteLine("Thang khong hop le!");

//        Console.WriteLine("\nNhan phim bat ky de thoat...");
//        Console.ReadKey();
//    }
//}


//Thực hành 5: Viết chương trình nhập vào một số nguyên n để viết chẵn lẽ, âm hay ko âm

//class Program
//{
//    static void Main(string[] args)
//    {
//        // Nhap so nguyen n
//        Console.Write("Nhap so nguyen n: ");
//        int n = Convert.ToInt32(Console.ReadLine());

//        Console.WriteLine("\n--- KET QUA ---");

//        // a) Kiem tra chan le
//        if (n % 2 == 0)
//            Console.WriteLine("n la so chan");
//        else
//            Console.WriteLine("n la so le");

//        // b) Kiem tra am hay khong am
//        if (n < 0)
//            Console.WriteLine("n la so am");
//        else
//            Console.WriteLine("n la so khong am");

//        Console.WriteLine("\nNhan phim bat ky de thoat...");
//        Console.ReadKey();
//    }
//}


//Thực hành 6: Viết chương trình nhập vào 2 số thực dương chỉ chiều dài và chiều rộng
using System;

//class Program
//{
//    static void Main(string[] args)
//    {
//        // Nhap chieu dai
//        Console.Write("Nhap chieu dai: ");
//        double dai = Convert.ToDouble(Console.ReadLine());

//        // Nhap chieu rong
//        Console.Write("Nhap chieu rong: ");
//        double rong = Convert.ToDouble(Console.ReadLine());

//        // Kiem tra so duong
//        if (dai <= 0 || rong <= 0)
//        {
//            Console.WriteLine("Chieu dai va chieu rong phai la so duong");
//        }
//        else
//        {
//            // Tinh chu vi va dien tich
//            double chuVi = (dai + rong) * 2;
//            double dienTich = dai * rong;

//            // In ket qua
//            Console.WriteLine("\n--- KET QUA ---");
//            Console.WriteLine("Chu vi hinh chu nhat = " + chuVi);
//            Console.WriteLine("Dien tich hinh chu nhat = " + dienTich);
//        }

//        Console.WriteLine("\nNhan phim bat ky de thoat...");
//        Console.ReadKey();
//    }
//}

//Thực hành 7: Viết chương trình nhập vào ba số thực chỉ độ dài của ba đoạn thẳng.Kiểm tra nếu ba đoạn thẳng này lập thành được một tam giá thì hiển thị
//chu vi và diện tích của tam giác đó.

//using System;

//class Program
//{
//    static void Main(string[] args)
//    {
//        // Nhap do dai 3 canh
//        Console.Write("Nhap canh a: ");
//        double a = Convert.ToDouble(Console.ReadLine());

//        Console.Write("Nhap canh b: ");
//        double b = Convert.ToDouble(Console.ReadLine());

//        Console.Write("Nhap canh c: ");
//        double c = Convert.ToDouble(Console.ReadLine());

//        Console.WriteLine("\n--- KET QUA ---");

//        // Kiem tra dieu kien tam giac
//        if (a > 0 && b > 0 && c > 0 && a + b > c && a + c > b && b + c > a)
//        {
//            double chuVi = a + b + c;
//            double p = chuVi / 2;
//            double dienTich = Math.Sqrt(p * (p - a) * (p - b) * (p - c));

//            Console.WriteLine("Chu vi tam giac = " + chuVi);
//            Console.WriteLine("Dien tich tam giac = " + dienTich);
//        }
//        else
//        {
//            Console.WriteLine("Ba canh nay khong lap thanh tam giac");
//        }

//        Console.WriteLine("\nNhan phim bat ky de thoat...");
//        Console.ReadKey();
//    }
//}


//Thực hành 8: Viết chương trình giải phương trình bậc 2: ax2 + bx + c = 0.
//using System;

//class Program
//{
//    static void Main(string[] args)
//    {
//        // Nhap he so a, b, c
//        Console.Write("Nhap a: ");
//        double a = Convert.ToDouble(Console.ReadLine());

//        Console.Write("Nhap b: ");
//        double b = Convert.ToDouble(Console.ReadLine());

//        Console.Write("Nhap c: ");
//        double c = Convert.ToDouble(Console.ReadLine());

//        Console.WriteLine("\n--- KET QUA ---");

//        if (a == 0)
//        {
//            // Phuong trinh bac nhat bx + c = 0
//            if (b == 0)
//            {
//                if (c == 0)
//                    Console.WriteLine("Phuong trinh vo so nghiem");
//                else
//                    Console.WriteLine("Phuong trinh vo nghiem");
//            }
//            else
//            {
//                double x = -c / b;
//                Console.WriteLine("Phuong trinh co nghiem x = " + x);
//            }
//        }
//        else
//        {
//            double delta = b * b - 4 * a * c;

//            if (delta < 0)
//            {
//                Console.WriteLine("Phuong trinh vo nghiem");
//            }
//            else if (delta == 0)
//            {
//                double x = -b / (2 * a);
//                Console.WriteLine("Phuong trinh co nghiem kep x = " + x);
//            }
//            else
//            {
//                double x1 = (-b + Math.Sqrt(delta)) / (2 * a);
//                double x2 = (-b - Math.Sqrt(delta)) / (2 * a);
//                Console.WriteLine("Phuong trinh co 2 nghiem phan biet:");
//                Console.WriteLine("x1 = " + x1);
//                Console.WriteLine("x2 = " + x2);
//            }
//        }

//        Console.WriteLine("\nNhan phim bat ky de thoat...");
//        Console.ReadKey();
//    }
//}


//Thực hành 9: Tính tổng các phần tử trong mảng.

//using System;

//class Program
//{
//    static void Main(string[] args)
//    {
//        // Nhap so phan tu cua mang
//        Console.Write("Nhap so phan tu n: ");
//        int n = Convert.ToInt32(Console.ReadLine());

//        int[] arr = new int[n];
//        int tong = 0;

//        // Nhap cac phan tu
//        for (int i = 0; i < n; i++)
//        {
//            Console.Write("Nhap phan tu thu " + (i + 1) + ": ");
//            arr[i] = Convert.ToInt32(Console.ReadLine());
//            tong += arr[i]; // cong vao tong
//        }

//        // In ket qua
//        Console.WriteLine("\n--- KET QUA ---");
//        Console.WriteLine("Tong cac phan tu trong mang = " + tong);

//        Console.WriteLine("\nNhan phim bat ky de thoat...");
//        Console.ReadKey();
//    }
//}


//Thực hành 10: Dùng giải thuật sắp xếp chọn (Selection Sort) để sắp xếp tăng dần mảng các số nguyên. Mảng các số nguyên được lưu trong tệp văn bản có tên
//là “input_array.txt”.

//using System;
//using System.IO;

//class Program
//{
//    static void Main(string[] args)
//    {
//        try
//        {
//            // Doc du lieu tu file
//            string filePath = "input_array.txt";
//            string content = File.ReadAllText(filePath);

//            // Tach cac so va chuyen thanh mang int
//            string[] parts = content.Split(new char[] { ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries);
//            int[] arr = Array.ConvertAll(parts, int.Parse);

//            // Thuat toan selection sort
//            for (int i = 0; i < arr.Length - 1; i++)
//            {
//                int minIndex = i;
//                for (int j = i + 1; j < arr.Length; j++)
//                {
//                    if (arr[j] < arr[minIndex])
//                    {
//                        minIndex = j;
//                    }
//                }
//                // Hoan doi
//                int temp = arr[i];
//                arr[i] = arr[minIndex];
//                arr[minIndex] = temp;
//            }

//            // In ket qua
//            Console.WriteLine("--- KET QUA ---");
//            Console.WriteLine("Mang sau khi sap xep tang dan:");
//            foreach (int num in arr)
//            {
//                Console.Write(num + " ");
//            }
//        }
//        catch (Exception ex)
//        {
//            Console.WriteLine("Loi: " + ex.Message);
//        }

//        Console.WriteLine("\n\nNhan phim bat ky de thoat...");
//        Console.ReadKey();
//    }
//}


//Thực hành 11: Chèn thêm một số nguyên được nhạp vào từ bàn phím vào mảng đã sắp xếp tăng dần nhưng không làm mất tính tăng dần của mảng.
using System;

class Program
{
    static void Main(string[] args)
    {
        // Vi du mang da sap xep tang dan
        int[] arr = { 1, 3, 5, 7, 9 };

        // In mang ban dau
        Console.WriteLine("Mang ban dau:");
        foreach (int num in arr)
        {
            Console.Write(num + " ");
        }

        // Nhap so can chen
        Console.Write("\n\nNhap so nguyen can chen: ");
        int x = Convert.ToInt32(Console.ReadLine());

        // Tao mang moi co do dai tang 1
        int[] newArr = new int[arr.Length + 1];
        int i = 0, j = 0;
        bool inserted = false;

        while (i < arr.Length)
        {
            if (!inserted && x < arr[i])
            {
                newArr[j++] = x;
                inserted = true;
            }
            else
            {
                newArr[j++] = arr[i++];
            }
        }

        // Neu x lon hon tat ca thi chen vao cuoi
        if (!inserted)
        {
            newArr[j] = x;
        }

        // In mang moi
        Console.WriteLine("\nMang sau khi chen:");
        foreach (int num in newArr)
        {
            Console.Write(num + " ");
        }

        Console.WriteLine("\n\nNhan phim bat ky de thoat...");
        Console.ReadKey();
    }
}
