namespace TrongNhan_1050080148_BTtuan7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
    }
}
